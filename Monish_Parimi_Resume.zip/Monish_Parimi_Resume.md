﻿Parimi Monish Last Updated on 4th August 2023![](Aspose.Words.f6c2eeb4-0b87-401b-95d9-db3c13fd8676.001.png)![](Aspose.Words.f6c2eeb4-0b87-401b-95d9-db3c13fd8676.002.jpeg)

[parimimonish@gmail.com|](mailto:srijaparimi@gmail.com) 9361407629![](Aspose.Words.f6c2eeb4-0b87-401b-95d9-db3c13fd8676.003.png)

EDUCATION

**VIT UNIVERSITY**

B.Tech Computer Science in AI and ML

2021-2025

Amaravahi India

CGPA: 8.46

**SHRADDHA CHILDREN'S ACADEMY**

XII Standard May 2021 Chennai, India Percentage : 86

**S.B.O.A SCHOOL AND JUNIOR COLLEGE**

X Standard May 2019 Chennai, India Percentage : 88

COURSEWORK

**UNDERGRADUATE** DatabaseManagementSystems OperatingSystems DataStructuresandAlgorithms NetworkandCommunication MachineLearning ArtificialIntelligence

SKILLS

**TECHNICAL SKILLS**

LANGUAGES •Python•JAVA WEB DEV

- HTML• CSS APP DEV
- Androidstudio

LANGUAGES

Fluent

English|Hindi

Intermediate Tamil|Telugu|French|German

EXTRA-CURRICULAR

**ANDROID CLUB**

Creative and Content Team Member

July 2022 - Present

- Workedas a Creativeteammemberanddesignedtemplatesand postersfortheclub’ssocialmediapages.
- Collaboratedwithotherteammembersandpromotedthecluband itseventsforbetterreach.
- Coordinatedandhosteda Workshopon Figma(UI/UX)and conducteda DESIGNATHON duringVTAPP(TechFest) on behalfof theclub.
- Learnedtobe a teamplayeranda goodlistenerwithanopenmind.

**DRUSHYA ANIMATION AND GAMING CLUB**

Design Team Member September 2022 - Present

- Aspartof theDesignteamI createdvariouspostersfortheClub promotion.
- Hosteda Callof DutyMobileTournamentduringVTAPPand monitoredtheparticipantsandmanagedtheScoreboardforfairplay.
- Hosteda VALORANTTournamentbybestutilizingthecollege resources.
- Learnedtoefficientlymanagethebudgetandresources.

PROJECT WORK

**DOG BREED CLASSIFICATION**

July 2023 – Aug 2023

- Createda Dog breedclassifiedusingdeeplearningalgorithms VGG16 andVGG19.
- Augmentedthedata,addedoptimizersandregularisationtoimprove thetrainingandtestingaccuracyof themodel.
- Optimallytrainedthemodeltoreducethechanceof Overfitting.
- Used GoogleColab,TensorflowStanford-DogDataset.

**DOORBELL FACE DETECTION USING RASPBERRY PI**

SEP 2019 – NOV 2019

- Createda doorbellfaceauthenticationtoenhancesecurity.
- Createda DeepLearningmodelforfacerecognitionand identification.If thefaceis notidentifiedthenthesystemwillsendan alerttothehouseowners.
- Theimageis processedbythesystemandthefaceis chosenas the ROI.
- Used OpenCV,RaspberryPI,Pandas,
